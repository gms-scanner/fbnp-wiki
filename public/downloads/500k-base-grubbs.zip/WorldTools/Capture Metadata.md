# smp.player2.game World Save - Snapshot Details
![Server Icon](../icon.png)

- **Time**: `Fri, 29 Aug 2025 12:29:40 -0500` (Timestamp: `1756488580454`)
- **Captured By**: `GrubbyKnight698`

## Server
- **IP**: `smp.player2.game`
- **Capacity**: `0/60`
- **Brand**: `fabric`
- **MOTD**: `The §6§lOfficial§r §bPlayer2§r SMP`
- **Version**: `1.21.4 (Player2 Supported)`
- **Protocol Version**: `769`
- **Server Type**: `OTHER`

## Connection
- **Host Name**: `170.205.25.53`
- **Port**: `25565`
- **Session ID**: `886bd105-1746-47ef-817b-12f04a46b0ee`

This file was created by [WorldTools 1.2.8](https://github.com/Avanatiker/WorldTools/)
